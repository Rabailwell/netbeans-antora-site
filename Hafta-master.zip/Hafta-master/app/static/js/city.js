const CityForm =
{
    template: '#city_form',
    data() {
        return {
            view: true,
            form: {
                errors: [],
                id: null,
                name: null,
                mssg: null
            },
            data: null,
            modal: false,
            edit: {
                errors: [],
                name: null,
                mssg: null
            },
            confirm: false,
            ascending: false,
            sortColumn: '',
        }
    },
    watch: {
        data: function () {
            feather.replace()
        }
    },
    delimiters: ["[[", "]]"],
    mounted() {
        feather.replace();
        this.focusInput();
    },
    methods: {
        focusInput() {
            this.$refs.name.focus();
        },
        checkData(e) {
            this.form.errors = []
            if (this.form.name) {

                return true;
            }



            if (!this.form.name) {
                this.form.errors.push('City required');
                this.$buefy.snackbar.open({
                    duration: 4000,
                    message: 'City required',
                    type: 'is-light',
                    position: 'is-top-right',
                    actionText: 'Close',
                    queue: true,
                    onAction: () => {
                        this.isActive = false;
                    }
                })
            }

        },

        submitData(e) {
            this.checkData(e);
            var formdata = this;

            if (this.form.errors.length == 0) {
                axios
                    .post('/master/add/city', this.form)
                    .then(function (response) {
                        formdata.form.mssg = response['data']
                        formdata.form.name = null;

                        formdata.$buefy.snackbar.open({
                            duration: 4000,
                            message: response.data.success,
                            type: 'is-light',
                            position: 'is-top-right',
                            actionText: 'Close',
                            queue: true,
                            onAction: () => {
                                this.isActive = false;
                            }
                        })
                    })
                    .catch(function (error) {
                        console.log(error)
                    })
            }
            e.preventDefault();
            this.focusInput()
        },
        getData(e) {
            const formdata = this;

            axios
                .get('/master/get/city')
                .then(function (response) {
                    console.log(response);
                    formdata.data = response['data']

                })
                .catch(function (error) {
                    console.log(error)
                });

            e.preventDefault();
        },
        editData(data) {
            this.edit.errors = []

            this.modal = true
            this.edit.name = data.name
            this.edit.id = data.id

        },
        saveEditData(e) {
            const formdata = this;
            var data = this.data;
            if (this.edit.name) {

                axios
                    .post('/master/edit/city', this.edit)
                    .then(function (response) {
                        console.log(response.data.success)
                        if (response.data.success) {
                            data = data.filter(function (x) { return x.id === formdata.edit.id })
                            data[0].name = formdata.edit.name
                            formdata.modal = !formdata.modal;

                            formdata.$buefy.snackbar.open({
                                duration: 4000,
                                message: response.data.success,
                                type: 'is-light',
                                position: 'is-top-right',
                                actionText: 'Close',
                                queue: true,
                                onAction: () => {
                                    this.isActive = false;
                                }
                            })
                        }
                        else {
                            formdata.edit.errors.push(response.data)

                            formdata.$buefy.snackbar.open({
                                duration: 4000,
                                message: response.data.message,
                                type: 'is-light',
                                position: 'is-top-right',
                                actionText: 'Close',
                                queue: true,
                                onAction: () => {
                                    this.isActive = false;
                                }
                            })
                        }

                    })
                    .catch(function (error) {
                        console.log(error)
                    })
            }


            this.edit.errors = []
            console.log(this.edit.name)

            if (this.edit.name == "") {
                this.edit.errors.push('City required');

            }

            e.preventDefault();

        },
        deleteData(data, index) {
            // const removeId = data.id; 
            console.log(data);
            var datalist = this.data;

            axios
                .post('/master/delete/city', data)
                .then(function (response) {
                    if (response.data.success) {
                        datalist.splice(index, 1)
                        formdata.$buefy.snackbar.open({
                            duration: 4000,
                            message: response.data.success,
                            type: 'is-light',
                            position: 'is-top-right',
                            actionText: 'Close',
                            queue: true,
                            onAction: () => {
                                this.isActive = false;
                            }
                        })
                    }
                })
                .catch(function (error) {
                    console.log(error)
                    formdata.$buefy.snackbar.open({
                        duration: 4000,
                        message: error,
                        type: 'is-light',
                        position: 'is-top-right',
                        actionText: 'Close',
                        queue: true,
                        onAction: () => {
                            this.isActive = false;
                        }
                    })
                })
        },
        selectRow() {

        },
    }
}
